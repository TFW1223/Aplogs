"""Вспомогательные функции проекта."""
from datetime import datetime

from dateutil import parser as date_parser


def is_date(string):
    """Строка является датой?"""
    try:
        date_parser.parse(string, dayfirst=True)
        return True
    except ValueError or TypeError:
        return False


async def check_and_parse_date(date):
    """Проверить и преобразовать дату, если необходимо."""
    if date and not isinstance(date, datetime):
        if not is_date(date):
            raise ValueError(f"Ошибка: Некорректный формат даты для {date}.")
        else:
            date = date_parser.parse(date, dayfirst=True)
    return date
