"""Вспомогательные классы проекта."""
import json
from datetime import datetime


class CustomJSONEncoder(json.JSONEncoder):
    """Кастомная кодировка json."""

    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)
