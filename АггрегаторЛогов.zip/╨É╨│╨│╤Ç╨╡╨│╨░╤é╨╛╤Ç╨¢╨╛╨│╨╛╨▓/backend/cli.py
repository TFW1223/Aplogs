"""Команды для работы с парсингом логов из консоли."""
import functools
import json

import asyncclick as aclick
import click

from db.db_handler import connect_to_db, disconnect_from_db
from logs.log_parser import (get_filtered_log_objects, get_log_objects,
                             save_log_objects)
from utils.help_classes import CustomJSONEncoder


def db_connection_handler(func):
    """Декоратор управления соединением с БД."""
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        await connect_to_db()
        try:
            result = await func(*args, **kwargs)
        finally:
            await disconnect_from_db()
        return result
    return wrapper


@aclick.group()
def cli():
    pass


@cli.command()
@db_connection_handler
@aclick.option("--log-file", type=str, required=False,
               help="Путь до файла с логами")
async def parse_logs(log_file):
    """Команда 'Собрать и сохранить логи в БД.'"""
    await save_log_objects(log_file)
    click.echo("Логи успешно сохранены!")


@cli.command()
@db_connection_handler
async def get_logs():
    """Команда 'Получить логи из БД.'"""
    logs = await get_log_objects()
    click.echo("Начало вывода логов:")
    logs_json = [log.to_dict() for log in logs]
    logs_json_str = json.dumps(
        logs_json,
        indent=4,
        ensure_ascii=False,
        cls=CustomJSONEncoder)
    click.echo(logs_json_str)
    click.echo("Логи успешно выведены!")


@cli.command()
@db_connection_handler
@aclick.option("--start-date", type=str, required=False,
               help="Стартовая дата для фильтрации логов")
@aclick.option("--end-date", type=str, required=False,
               help="Крайняя дата для фильтрации логов")
@aclick.option("--ip-address", type=str, required=False,
               help="IP адрес для фильтрации логов")
async def filter_logs(start_date, end_date, ip_address):
    """Команда 'Отфильтровать (найти) логи по параметрам.'"""
    try:
        filtered_logs = await get_filtered_log_objects(start_date, end_date, ip_address)
        click.echo("Начало вывода логов:")
        logs_json = [log.to_dict() for log in filtered_logs]
        logs_json_str = json.dumps(
            logs_json,
            indent=4,
            ensure_ascii=False,
            cls=CustomJSONEncoder)
        click.echo(logs_json_str)
        click.echo("Логи успешно выведены!")
    except ValueError as e:
        click.echo(f"Ошибка: {str(e)}")

if __name__ == "__main__":
    cli()
