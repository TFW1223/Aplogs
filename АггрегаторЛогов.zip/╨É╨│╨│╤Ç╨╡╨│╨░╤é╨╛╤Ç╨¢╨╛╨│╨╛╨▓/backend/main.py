"""Файл запуска приложения."""
from fastapi import FastAPI

from api.views import router
from db.db_handler import connect_to_db, disconnect_from_db

app = FastAPI()

app.include_router(router)


@app.on_event("startup")
async def startup_event():
    """Обработчик при запуске приложения."""
    await connect_to_db()


@app.on_event("shutdown")
async def shutdown_event():
    """Обработчик при завершении приложения."""
    await disconnect_from_db()
