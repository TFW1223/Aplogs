"""Настройки проекта."""
import os

from dotenv import load_dotenv

load_dotenv(dotenv_path='./infra/.env')

# Путь к папке с логами Apache
LOGS_DIR = "/var/log/apache2"
# Маска имени файлов логов
LOG_FILENAME_PATTERN = "*.log"

# Параметры подключения к базе данных PostgreSQL
POSTGRES_USER = str(os.getenv('POSTGRES_USER'))
POSTGRES_PASSWORD = str(os.getenv('POSTGRES_PASSWORD'))
DB_HOST = os.getenv('DB_HOST')
DB_PORT = os.getenv('DB_PORT')
DB_NAME = str(os.getenv('DB_NAME'))
POSTGRES_URI = f'postgresql://{POSTGRES_USER}:{POSTGRES_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}'

# Шаблон для анализа логов
LOG_REGEX = r'(?P<ip_address>\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}) - - \[(?P<date_time>.*?)\] "(?P<method>\w+) (?P<url>.+)" (?P<status>\d{3}) (?P<size>\d+|-) "(?P<user_agent>.*?)"'
