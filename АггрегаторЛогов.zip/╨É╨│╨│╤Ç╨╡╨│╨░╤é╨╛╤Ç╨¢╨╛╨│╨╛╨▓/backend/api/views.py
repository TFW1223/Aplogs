"""Функции представления API."""
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Query

from logs.log_parser import (get_filtered_log_objects, get_log_objects,
                             save_log_objects)

router = APIRouter()


@router.post("/parse_logs")
async def parse_logs(log_file: str = None):
    """Представление 'Собрать и сохранить логи в БД.'"""
    await save_log_objects(log_file)
    return {"message": "Логи обработаны и сохранены успешно!"}


@router.get("/logs")
async def get_logs():
    """Представление 'Получить логи из БД.'"""
    logs = await get_log_objects()
    return {"logs": [log.to_dict() for log in logs]}


@router.get("/logs/filter")
async def filter_logs(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    ip_address: Optional[str] = Query(None),
):
    """Представление 'Отфильтровать (найти) логи по параметрам.'"""
    filtered_logs = await get_filtered_log_objects(start_date, end_date, ip_address)
    return {"logs": [log.to_dict() for log in filtered_logs]}
