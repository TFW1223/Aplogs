"""Файл инициализации БД."""
from gino import Gino

db = Gino()
