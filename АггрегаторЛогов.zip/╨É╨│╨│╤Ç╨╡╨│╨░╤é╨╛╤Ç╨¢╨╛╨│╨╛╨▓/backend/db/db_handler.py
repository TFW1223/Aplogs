"""Функция для работы с БД."""
from infra.settings import POSTGRES_URI

from .db_init import db


async def connect_to_db():
    await db.set_bind(POSTGRES_URI)
    await db.gino.create_all()


async def disconnect_from_db():
    await db.pop_bind().close()
