"""Модели для работы с БД."""
import sqlalchemy as sa

from .db_handler import db


class LogEntry(db.Model):
    """Модель данных о логе"""
    __tablename__ = "log_entries"

    id = db.Column(sa.Integer, primary_key=True)
    date_time = db.Column(sa.DateTime(), nullable=False)
    ip_address = db.Column(sa.String(255), nullable=False)
    method = db.Column(sa.String(10), nullable=False)
    url = db.Column(sa.Text(), nullable=False)
    status = db.Column(sa.Integer(), nullable=False)
    size = db.Column(sa.Integer(), nullable=False)
    user_agent = db.Column(sa.String(), nullable=True)
