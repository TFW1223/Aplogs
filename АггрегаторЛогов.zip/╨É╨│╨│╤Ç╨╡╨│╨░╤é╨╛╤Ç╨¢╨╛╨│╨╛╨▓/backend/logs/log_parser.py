"""Парсинг логов."""
import fnmatch
import logging
import os
import re
from datetime import datetime

import aiofiles

from db.models import LogEntry
from infra import settings
from utils.help_functions import check_and_parse_date


async def parse_log_line(log_line):
    """Собрать данные из строки с логом."""
    match = re.match(settings.LOG_REGEX, log_line)
    if match:
        data = match.groupdict()

        naive_datetime = datetime.strptime(
            data['date_time'], '%d/%b/%Y:%H:%M:%S %z')
        date_time = naive_datetime.replace(tzinfo=None)

        data['date_time'] = date_time
        data['status'] = int(data['status'])
        data['size'] = int(data['size'])
        return data
    return None


async def parse_logs(log_file):
    """Собрать данные из всех строк с логами."""
    parsed_logs = []
    log_files = []

    if not log_file:
        log_dir = settings.LOGS_DIR
        for file in os.listdir(log_dir):
            if fnmatch.fnmatch(file, settings.LOG_FILENAME_PATTERN):
                log_files.append(os.path.join(log_dir, file))
    else:
        log_files = [log_file]

    for file in log_files:
        try:
            async with aiofiles.open(file, 'r') as f:
                async for line in f:
                    data = await parse_log_line(line)
                    if data:
                        parsed_logs.append(data)
        except FileNotFoundError:
            logging.error(f"Файл {file} не найден.")

    return parsed_logs


async def save_log_objects(log_file):
    """Собрать и сохранить логи в БД."""
    parsed_logs = await parse_logs(log_file)
    for log_entry in parsed_logs:
        try:
            existing_log = await LogEntry.query.where(
                (LogEntry.date_time == log_entry['date_time']) &
                (LogEntry.ip_address == log_entry['ip_address'])
            ).gino.first()
            if not existing_log:
                log = LogEntry(**log_entry)
                await log.create()
        except Exception as e:
            logging.error(f"Ошибка при сохранении лога: {e}")


async def get_log_objects():
    """Получить логи из БД."""
    logs = await LogEntry.query.gino.all()
    return logs


async def get_filtered_log_objects(start_date, end_date, ip_address):
    """Отфильтровать (найти) логи по параметрам."""
    start_date = await check_and_parse_date(start_date)
    end_date = await check_and_parse_date(end_date)

    all_logs = await LogEntry.query.gino.all()
    filtered_logs = all_logs

    if start_date:
        filtered_logs = [
            log for log in filtered_logs if log.date_time >= start_date]
    if end_date:
        filtered_logs = [
            log for log in filtered_logs if log.date_time <= end_date]
    if ip_address:
        filtered_logs = [
            log for log in filtered_logs if log.ip_address == ip_address]

    return filtered_logs
