# Postgresql

 В проекте используется postgresql, поэтому перед тем как запускать сам проект,
 необходимо установить postgres и создать базу данных.

 ## Установка под windows:

 Скачайте установщик на сайте: https://www.postgresql.org/download/windows/
 подробнее можно прочить например тут:
 https://docs.rkeeper.ru/rk7/7.7.0/ru/ustanovka-postgresql-na-windows-29421153.html

 ## Установка PostgreSQL в Ubuntu:

 ```sh
sudo apt update
sudo apt install postgresql postgresql-contrib
```

## Запустите и включите службу PostgreSQL:

```sh
sudo systemctl start postgresql
sudo systemctl enable postgresql
```
## Подключитесь к postgres:

```sh
sudo -u postgres psql
```

## Задайте новый пароль для пользователя postgres:

```sql
ALTER USER postgres PASSWORD 'postgres';
```
## Создайте новую базу данных:

```sql
CREATE DATABASE apache_logs;
```

После этого можете переходить к дальнейшим шагам, по запуску проекта.
