from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .apache_log_aggregator.views import LogEntryViewSet

router = DefaultRouter()
router.register(r"logs", LogEntryViewSet)

urlpatterns = [
    path("", include(router.urls)),
]
