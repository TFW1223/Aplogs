from rest_framework import viewsets
from apps.apache_log_aggregator.models import LogEntry
from apps.apache_log_aggregator.serializers import LogEntrySerializer
from rest_framework.response import Response
from django.db.models import Count, Q
from rest_framework import status
from django.core.management import call_command
from datetime import datetime
from rest_framework.decorators import action


class LogEntryViewSet(viewsets.ModelViewSet):
    """
    Returns a list of all logs in the database.
    """

    queryset = LogEntry.objects.all()
    serializer_class = LogEntrySerializer

    @action(detail=False, methods=["get"])
    def grouped(self, request):
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")
        group_by = request.query_params.get("group_by")

        query = Q()
        if start_date:
            try:
                start_date = datetime.strptime(start_date, "%Y-%m-%d")
                query &= Q(datetime__gte=start_date)
            except ValueError:
                return Response(
                    {"error": "Invalid start date format"},
                    status=status.HTTP_400_BAD_REQUEST,
                )
        if end_date:
            try:
                end_date = datetime.strptime(end_date, "%Y-%m-%d")
                query &= Q(datetime__lte=end_date)
            except ValueError:
                return Response(
                    {"error": "Invalid end date format"},
                    status=status.HTTP_400_BAD_REQUEST,
                )

        if group_by == "ip":
            logs = (
                LogEntry.objects.filter(query)
                .values("ip_address")
                .annotate(count=Count("ip_address"))
                .order_by("-count")
            )
        elif group_by == "date":
            logs = (
                LogEntry.objects.filter(query)
                .extra({"date": "DATE(datetime)"})
                .values("date")
                .annotate(count=Count("id"))
                .order_by("-date")
            )
        else:
            return Response(
                {"error": "Invalid group_by parameter. Use 'ip' or 'date'."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        return Response(logs, status=status.HTTP_200_OK)

    @action(detail=False, methods=["get"])
    def parse_logs(self, request):
        try:
            call_command("parse_logs")
            return Response(
                {"message": "Log parsing started successfully"},
                status=status.HTTP_200_OK,
            )
        except Exception as e:
            return Response(
                {"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
