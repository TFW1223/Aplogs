from django.contrib import admin
from .models import LogEntry, User


@admin.register(LogEntry)
class LogEntryAdmin(admin.ModelAdmin):
    list_display = ("ip_address", "datetime", "request", "status_code", "user_agent")
    list_filter = ("ip_address", "datetime", "status_code")


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ("username", "password")
