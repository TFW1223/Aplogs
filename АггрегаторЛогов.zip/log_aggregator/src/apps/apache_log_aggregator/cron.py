from .log_parser import parse_log_line
from .models import LogEntry
from django.conf import settings
import os
import logging


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def parse_logs_cron():
    entries = []
    log_files_path = settings.LOG_FILES_PATH
    log_file_mask = settings.LOG_FILE_MASK
    logger.info("log_files_path: %", log_files_path)
    logger.info("log_file_mask: %", log_file_mask)
    for file_name in os.listdir(log_files_path):
        if log_file_mask in file_name:
            logger.info("log_file_mask in file_name")
            with open(os.path.join(log_files_path, file_name)) as f:
                for line in f:
                    log_entry = parse_log_line(line)
                    if log_entry:
                        entries.append(log_entry)
                        logger.info("log_entry log_entry added to bulk")
    LogEntry.objects.bulk_create(entries, ignore_conflicts=True)
    logger.info("bulk create objects")
