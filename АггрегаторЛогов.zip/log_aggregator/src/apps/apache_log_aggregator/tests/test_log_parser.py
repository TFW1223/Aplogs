# import django
# import os
# import sys
import pytest
from ..log_parser import parse_log_line
from datetime import datetime


@pytest.mark.django_db
def test_parse_log_line():
    line = '127.0.0.1 - - [12/Dec/2020:19:45:23 +0000] "GET / HTTP/1.1" 200 612 "-" "curl/7.68.0"'
    log_entry = parse_log_line(line)
    assert log_entry.ip_address == "127.0.0.1"
    assert log_entry.datetime == datetime(2020, 12, 12, 19, 45, 23)
    assert log_entry.request == "GET / HTTP/1.1"
    assert log_entry.status_code == 200
    assert log_entry.user_agent == "curl/7.68.0"
