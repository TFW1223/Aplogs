from django.core.management.base import BaseCommand
from apps.apache_log_aggregator.log_parser import parse_log_line
from apps.apache_log_aggregator.models import LogEntry
from django.conf import settings
import os
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = "Parse Apache log files"

    def handle(self, *args, **kwargs):
        entries = []
        log_files_path = settings.LOG_FILES_PATH
        log_file_mask = settings.LOG_FILE_MASK
        logger.info("filepath --  %s", log_files_path)
        logger.info("filemask --  %s", log_file_mask)
        for file_name in os.listdir(log_files_path):
            logger.info("fn --  %s", file_name)
            if log_file_mask in file_name:
                logger.info("filemask in filename")
                with open(os.path.join(log_files_path, file_name)) as f:
                    for line in f:
                        log_entry = parse_log_line(line)
                        logger.info(f"--- {log_entry}")
                        if log_entry:
                            entries.append(log_entry)
                            logger.info("log_entry added to bulk")
        LogEntry.objects.bulk_create(entries, ignore_conflicts=True)
        logger.info("LogEntry bulk created")
        self.stdout.write(self.style.SUCCESS("Successfully parsed log files"))
