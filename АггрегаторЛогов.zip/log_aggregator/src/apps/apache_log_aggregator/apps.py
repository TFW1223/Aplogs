from django.apps import AppConfig


class ApacheLogAggregatorConfig(AppConfig):
    name = "apps.apache_log_aggregator"
    default_auto_field = "django.db.models.BigAutoField"
