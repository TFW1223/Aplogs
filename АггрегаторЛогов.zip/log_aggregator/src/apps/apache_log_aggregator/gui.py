import os
import sys
import django
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from django.core.management import call_command
from datetime import datetime
from django.db.models import Q

_curdir = os.path.abspath(os.path.dirname(__file__))  # Текущая директория
_newdir = os.path.abspath(
    os.path.join(_curdir, "../../")
)  # Путь к корню Django-проекта

sys.path.remove(_curdir)  # Удаляем текущий путь
sys.path.insert(0, _newdir)  # Добавляем путь к корню
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
django.setup()

from apps.apache_log_aggregator.models import LogEntry


class LogParserApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Log Parser")
        self.geometry("800x600")

        self.create_widgets()

    def create_widgets(self):
        self.parse_button = ttk.Button(self, text="Parse Logs", command=self.parse_logs)
        self.parse_button.pack(pady=10)

        # Filters
        self.start_date_label = ttk.Label(self, text="Start Date (YYYY-MM-DD):")
        self.start_date_label.pack()
        self.start_date_entry = ttk.Entry(self)
        self.start_date_entry.pack()

        self.end_date_label = ttk.Label(self, text="End Date (YYYY-MM-DD):")
        self.end_date_label.pack()
        self.end_date_entry = ttk.Entry(self)
        self.end_date_entry.pack()

        self.ip_address_label = ttk.Label(self, text="IP Address:")
        self.ip_address_label.pack()
        self.ip_address_entry = ttk.Entry(self)
        self.ip_address_entry.pack()

        self.filter_button = ttk.Button(
            self, text="Filter Logs", command=self.filter_logs
        )
        self.filter_button.pack(pady=10)

        # Table for displaying logs
        self.tree = ttk.Treeview(
            self,
            columns=("IP Address", "Datetime", "Request", "Status Code", "User Agent"),
            show="headings",
        )
        self.tree.heading("IP Address", text="IP Address")
        self.tree.heading("Datetime", text="Datetime")
        self.tree.heading("Request", text="Request")
        self.tree.heading("Status Code", text="Status Code")
        self.tree.heading("User Agent", text="User Agent")

        self.tree.pack(fill=tk.BOTH, expand=True)
        logs = LogEntry.objects.all()
        self.display_logs(logs)

    def parse_logs(self):
        call_command("parse_logs")
        messagebox.showinfo("Info", "Logs parsed successfully")

    def filter_logs(self):
        start_date = self.start_date_entry.get()
        end_date = self.end_date_entry.get()
        ip_address = self.ip_address_entry.get()

        query = Q()
        if start_date:
            try:
                start_date = datetime.strptime(start_date, "%Y-%m-%d")
                query &= Q(datetime__gte=start_date)
            except ValueError:
                messagebox.showerror("Error", "Invalid start date format")
                return
        if end_date:
            try:
                end_date = datetime.strptime(end_date, "%Y-%m-%d")
                query &= Q(datetime__lte=end_date)
            except ValueError:
                messagebox.showerror("Error", "Invalid end date format")
                return
        if ip_address:
            query &= Q(ip_address__icontains=ip_address)

        logs = LogEntry.objects.filter(query)
        self.display_logs(logs)

    def display_logs(self, logs):
        # Clear the table
        for row in self.tree.get_children():
            self.tree.delete(row)

        # Insert new data
        for log in logs:
            self.tree.insert(
                "",
                "end",
                values=(
                    log.ip_address,
                    log.datetime,
                    log.request,
                    log.status_code,
                    log.user_agent,
                ),
            )


if __name__ == "__main__":
    app = LogParserApp()
    app.mainloop()
