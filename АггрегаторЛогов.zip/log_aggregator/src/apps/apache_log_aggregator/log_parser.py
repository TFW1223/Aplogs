import re
from datetime import datetime
from .models import LogEntry
import logging


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
LOG_PATTERN = re.compile(
    r'(?P<ip>[\d.]+) - - \[(?P<datetime>[^\]]+)\] "(?P<request>[^"]+)" (?P<status>\d{3}) (?P<size>\d+|-) "(?P<referrer>[^"]*)" "(?P<agent>[^"]*)"'
)


def parse_log_line(line):
    logger.info("line to parse: %s", line)
    match = LOG_PATTERN.match(line)
    if match:
        logger.info("line match pattern")
        data = match.groupdict()
        log_entry = LogEntry(
            ip_address=data["ip"],
            datetime=datetime.strptime(data["datetime"], "%d/%b/%Y:%H:%M:%S %z"),
            request=data["request"],
            status_code=int(data["status"]),
            user_agent=data["agent"],
        )
        logger.info(f"line parse -- {log_entry.__dict__}")
        return log_entry
    return None
